Color scheme: Triad RGB codes 64,189, 26 & 26,64,189 & 189,26,64 

I'm not sure how many we need? Here are 3 that may pair well if needed. Fonts

Reclame Script
I could not find. But I read this combined well with the next two. I looked up sister fonts as well--bakerie & brush script and could not find. It's like a street style font. If you can't find it either we can go with this one
Euphoria script
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Euphoria+Script&family=Poppins:wght@200&display=swap" rel="stylesheet">

Poppins Semi Bold
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">

Poppins Extra Light
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">
Paypal : Star3655@yahoo.com Venmo: Sudavida1988 Square, Afterpay, & Zelle also accepted. Payment plans available.

Logo : 

![2](https://github.com/Jennstar01/Information/assets/157870001/2a688d57-f92d-45f0-96e6-2bd33b72e39d)

****Mission statement/Goals Nutrition, training, paramedical artistry:****

Mission Statement:
At JStar Wellness LLC, my mission is to empower individuals on their journey to optimal well-being by providing personalized nutrition, training, and exercise coaching. As a dedicated Hair Tissue Mineral Analysis (HTMA) practitioner, I go beyond conventional approaches, delving into the unique needs and intricacies of each individual. In addition, I want to empower individuals through the transformative artistry of paramedical procedures, fostering confidence, and helping clients rediscover their natural beauty. I'm committed to providing personalized and compassionate services that go beyond skin-deep, catering to the unique needs and aspirations of each client.

My Approach:
I believe in meeting you exactly where you are, recognizing that every person is in a different season of life. By understanding your goals, needs, wants, and abilities, I tailor our coaching to create a customized plan that aligns with your aspirations. Whether you're looking to enhance your physical performance, improve your overall health, or achieve a specific fitness goal, I'm here to guide you.

In Paramedical Artistry my approach is centered on enhancing your natural features while addressing specific concerns. With a blend of artistic expertise and paramedical precision, I strive to create a harmonious fusion of aesthetics and personal expression.

Core Health Services:

Personalized Nutrition Coaching: 

I analyze your unique nutritional needs prior to creating the program for you. I can also use HTMA to create a deeper, customized nutrition plan that supports your body's balance and well-being. We utilize cutting edge techniques to assess mineral imbalances in your body, offering insights to potential health improvements.

Comprehensive Training Programs:

My exercise and training coaching are designed to meet you at your current fitness level, gradually guiding you towards your goals with personalized and effective routines.

Paramedical Artistry:
Additionally, as a skilled paramedical artist I specialize in stretch mark & scar rejuvenation camouflage, aiming to restore and enhance your natural beauty.

Personalized Consultations:
I believe in open and personalized consultations to understand your specific needs, ensuring that my services align seamlessly with your expectations.

Compassionate Care:
Beyond the technical aspects of my work, I prioritize creating a caring and supportive environment, fostering a sense of confidence and empowerment in every client.

My Commitment: 
My commitment extends beyond the artistic canvas to the well-being of my clients. I aim to not only provide exceptional services in this journey towards feeling and looking your best but also to be a source of encouragement and support. My goal is not just to help you achieve short-term results but to empower you with the knowledge and tools for long-term well-being while celebrating the uniqueness that makes each of us extraordinary.

Embrace your individuality. Embrace your season. Rediscover your confidence. Embrace your beauty. Let me be your partner in achieving holistic health, wellness, renewal and self expression.

****Why work with me:****

Why choose Jennifer's Wellness Services?

Are you seeking a wellness partner who brings two decades of expertise, a commitment to continuous learning, and a personalized approach tailored to your individuality? Look no further than Jennifer's Wellness Services. Here's why working with Jennifer is an investment in your holistic well-being:

1. A Two-Decade Legacy:
Jennifer boasts 20 years of rich experience in the Wellness industry. Her journey has been a tapestry of growth, learning, and a deep understanding that science continually evolves. This wealth of experience ensures that your wellness journey is guided by seasoned expertise.

2. Personalized Plans, Not Cookie-Cutter Solutions:
Recognizing that one size does not fit all, Jennifer is dedicated to crafting personalized nutrition and exercise plans. Before embarking on your wellness journey, she conducts a thorough and honest assessment, taking into account your genetics, experiences, traditions, and more. The result? A plan that aligns with your goals, needs, and lifestyle.

3. Education and Flexibility:
Experience a wealth of education and flexibility in your wellness journey. Jennifer believes in the "why" behind your specific plan. It's not just about the exercises or nutrition; it's about understanding and adopting a plan that works for you in the long run.About me Section:



4. Nutrition & Exercise Expertise: Jennifer offers online nutrition plans tailored to the season you're in and the one you're heading towards. Her expertise spans working with diverse populations, including kids, pregnant individuals, athletes, and more. Fat loss sprints and a focus on daily detoxification contribute to a holistic and sustainable approach.

Her training programs, designed for home or fitness facilities, are goal-specific and aim for adaptation, progression, and better functional movement, all while considering your unique abilities.

5. Hair Tissue Mineral Analysis Testing:
Uncover the raw data of what's happening inside your body through Hair Tissue Mineral Analysis Testing. This revealing service provides insights into heavy metals, food oxidation, mineral ratios, and their connections to hormones. A must-have resource that goes beyond traditional tests.

6. Paramedical Artistry Tattooing: Explore the world of non-invasive Paramedical Artistry Tattooing, an offering that extends beyond wellness into self-confidence. Jennifer's skilled use of a rotary machine stimulates your body's natural healing processes, improving skin texture, depth, and color. This service is a game-changer for addressing stretch marks, scars, and other skin concerns.


Jennifer's Wellness Services is your gateway to a wellness journey that celebrates your uniqueness. Embrace education, flexibility, and results crafted just for you. Your confidence, inside and out, begins here.

*****ABOUT ME*****

Early Spark:

Hi & welcome to my transformative journey. I'm a passionate individual whose odyssey in the Health & Wellness industry began in the heart of New Jersey in 2004.

At the tender age of 16, my interest was sparked by my father's subscription to Men's Health Magazine. Together, we embraced a fitness routine, turning our garage into a makeshift gym. These shared workouts became a weekly highlight, forging a connection between health, family, and the joy of physical activity.

Health Challenges:
Amidst this exploration, I faced a personal health challenge—a candida infection. Conventional solutions proved temporary, prompting me to delve deeper. A chance encounter with the "Acid & Alkaline Diet" not only cured my candida but ignited a fervor for understanding holistic health.
Early Career Steps:

My journey led me to work in various gyms while obtaining my personal training certification at 18. Simultaneously, I joined the Air Force National Guard, adding a unique dimension to my career path.

Diverse Certifications:

Driven by a thirst for knowledge, I pursued certifications ranging from Kids Sports Nutrition Mentor to Zumba Instructor and Group Fitness Instructor. I added cycling instruction to my repertoire in 2009, showcasing my commitment to a multifaceted approach to wellness.
Educational Pursuits:

Completing the Dietetic Technician Registered Nutrition Program at Middlesex County College and relocating to California marked pivotal moments in my academic and professional journey. Immersed in the health supplement industry, I continued to accumulate knowledge and certifications.

Jill of Many Trades:

I would say I'm a "Jill of many" in the industry. My expertise spans hormones, various exercise training modalities,gut health, athletes' nutrition, and stages of pregnancy. Recognizing the interconnectedness of mind, body, and spirit, I approach health holistically.
Innovative Services:

In 2023, I responded to high demand by adding two innovative services to my nutrition and training packages. I became a certified Hair Tissue Mineral Analysis Practitioner, collaborating with a lab to gain insights into clients' body states. Additionally, I embraced the role of a Paramedical Artist, using my skills to naturally camouflage stretch marks and scars.

My philosophy revolves around the holistic well-being of individuals. Beauty, health, and wellness intertwine in my practice, reflecting a commitment to empowering others on their unique paths to optimal health and self-discovery.

I continue to evolve, learn, and contribute to the well-being of those I serve, embodying the essence of a dedicated professional in the dynamic realm of Beauty & Wellness.

******Services Information & pricing:**

Paramedical Artistry

Color Match patch test $40

Acne Scars Inkless and/or Camouflage: 
Please send pictures or schedule a free consultation. Prices range from $125-$500. Discount given for more than 1 body part. Contact for pricing.

Needles produce micro traumas in the skin that causes your body to heal itself. It produces collagen and repairs the site causing skin lightening, tightening, circulation, reduced appearance, and texture improvement.

Scar Reduction & Revision:

Please send pictures or schedule a free consultation. Prices range from $120-$1200. Discount given for more than 1 body part. Contact for pricing. This price range includes ink and inkless services. Needles produce micro traumas in the skin that causes your body to heal itself. It produces collagen and repairs the site causing skin lightening, tightening, circulation, reduced appearance, and texture improvement.

Stretch Mark Collagen Induction Inkless/Camouflage 1 Body part:

Please send pictures or schedule a free consultation. Prices range from $300-$900. Discount given for more than 1 body part. Contact for pricing.

Needles produce micro traumas in the skin that causes your body to heal itself. It produces collagen and repairs the site causing skin lightening, tightening, circulation, reduced appearance, and texture improvement.

Nutrition & Training
Bodybuilding Competitor  nutrition, training, peak week Plans: $240 per month 8 weeks out

12-14 week online nutrition & training plan (non competitor): $249

Nutrition Lifestyle plan 12-14 weeks: $155

Sports Specific Athlete nutrition & training plan 12-14 weeks: $289

Online 12-14 week training plan: $155

Hair Tissue Mineral Analysis, 1 hour consultation, detox plan as pertains to results: $479

Hair Tissue Mineral Analysis, 1 hour Consultation, detox plan, transition lifestyle plan, 12-14 week training plan: $687

******Contact**

Email:
[Stepup2shapeup@gmail.com](mailto:Stepup2shapeup@gmail.com)
Phone:
805-268-7565
Location:
With online nutrition & training I can serve clients from all over the world.
Paramedical Artistry services located on 125 Union Avenue, Orcutt, CA

Payments accepted afterpay, square, venmo, paypal, zelle

Text only testimonials:

Here's my testimonial:

By utilizing Jenn's nutrition plan, for the first time in my life I found a healthy balance of the right amounts of foods and nutrients for my body. Instead of "dieting" and denying myself (always hungry), she helped me find the right foods to fuel my body and feel my best. My mentality went from depriving myself to making sure I add the right foods to be nutritious. She was consistent with checking in, and also a great encouragement. Her exercise plan was perfectly targeted to do from home or the gym and helped me focus areas I wanted to target, and gradually increased in intensity. -Kelly

It's too easy after getting a trainer like Jenn to dial me in. She listened to what I had to accomplish and developed a plan that's pretty much dummy proof. All I have to do is execute the designed workouts and eat the meals that are laid out for me. I even have an option for beers!! -Glenn

Never in a million years I'd ever thought I would wear a size 28 in Levis and here I am today at 40 years old doing it with the help and support of my trainer, Jenn. -Regina

My husband and I worked with Jenn doing a nutrition plan for several months.  I had previously tried working with another nutrition program and did not succeed. 
With Jenn however, I did. 

What sets her apart from others is not only her cost (which for many is a big factor) but her drive and knowledge.  She made sure to tailor a plan that was not only simple for both my husband and I, it was similar so we weren’t having to make additional meals for each, but also worked for our kids too.  She also unlike many other coaches follows up.  She is available to ask questions and get clarification. If something isn’t working she changes it.   

She is incredibly knowledgeable when it comes to women and their hormones and how to adjust things your body may be lacking.  She provided some great suggestions and alternative things for my husband who has an autoimmune disease.   Both my husband and I saw great results.   The best part, is it wasn’t a chore to follow and something we have adapted into our daily lifestyle.   

We both highly recommend working with Jenn! -Whitney & Joe

I wanted to get firmer, stronger and thinner on Jenn's program. More than that though I wanted a lifestyle change. With Jenn's help I found a nutrition program that has helped me with my stomach troubles and evened out my blood sugar highs and lows. As a 40 year old super busy mom of four I managed to lose some weight during the six weeks but better yet I've gained a nutrition and lifestyle change that will be easy to continue with indefinitely. Thanks Jenn!! -Shelly

I have had Workouts with Jen before and have seen results in as fast as a week. Very energetic and helpful with fitness and nutrition. Highly recommended for first timers and even those that already know more about fitness and nutrition. You could always learn more and that’s a good thing. -Aldo

I never thought my body could look as amazing as it did after working with Jenn. She completely transformed my physique and it blew my mind how well she knew my body and what would work for me. She always responded to emails and was there for me 110%. She cares about her clients and I couldnt have asked for a better trainer. -Kayla

When I wanted to compete in my first bikini competition I spoke wiht a fellow competitor an dshe referred me to Jenn. I thought what we had to do in such time wouldn't be achievable but I trusted her and the process and di it. She was nice, understanding, and easy going. I wanted to quit and she didnt let me. I went in 14-12 weeksfrom 155-138. I was blown away and placed at my show. This was a huge accomplishment for me. -Kim

Our journey consisted of changing our eating habits, we are now eating as healthy as we can and staying committed to attending the gym 3-5 days a week. Jenn has helped us meet our nutritional needs and she has also helped me with routines to aid in achieving my goals. Zumba is the reason why I even got started and that is where I met Jenn. - Maria & Rico

I started this fitness journey when I was overweight from 18-early 20s. My goal has always been to be healthy and fit. Now, at 30, I'm finally meeting that goal. This 6-week plan has been the most inspirational and I've lost inches and 10lbs!!! Not only am I following meal plans and workouts, I'm actually SUCCEEDING for the first time in my life and meeting a life-long goal of being healthy and fit AND I eat more food more often then before. It has made me more disciplined and I feel like the best version of myself! Thank you Jenn for inspiring me and teaching me how to live a healthy lifestyle. I look forward to another 6 weeks on the plan and the rest of my lifetime fitness journey! -Gina



![Bio Picture](https://github.com/Jennstar01/Information/assets/157870001/8d7dbbbd-2f5f-4190-9854-02f4d676c62e)


![2](https://github.com/Jennstar01/Information/assets/157870001/bcf74eae-6b79-4e97-9060-7d6691379d2e)



![fit 2](https://github.com/Jennstar01/Information/assets/157870001/745498af-8cb4-472d-b84e-858dd0ec4eeb)

![fit 3](https://github.com/Jennstar01/Information/assets/157870001/65f44dcc-7822-4368-aed9-4ae161f28aa8)

![fit 5](https://github.com/Jennstar01/Information/assets/157870001/b508f9f2-25e5-42c4-9203-7ec501dfa039)

![fit 13](https://github.com/Jennstar01/Information/assets/157870001/1e904b9e-fafd-4f75-a03d-7ef4ca71999c)

![fit 12](https://github.com/Jennstar01/Information/assets/157870001/6c935a20-d01e-4e85-b8d8-4ede136f18d6)

![fit 7](https://github.com/Jennstar01/Information/assets/157870001/8dde6af8-d5bd-40f9-9781-3d40ae5ebc77)

![fit 6](https://github.com/Jennstar01/Information/assets/157870001/55cf9663-13b8-419d-80d4-7e2f2369ecb5)

![fit 11](https://github.com/Jennstar01/Information/assets/157870001/244b3585-abb8-4259-af68-8a86629c68c3)

![fit 9](https://github.com/Jennstar01/Information/assets/157870001/00d0d04c-fde6-4572-a977-0cadc8f48706)

![fit 10](https://github.com/Jennstar01/Information/assets/157870001/3a5bafee-77f2-4ccb-8978-f5a58de75b8f)

![fit 8](https://github.com/Jennstar01/Information/assets/157870001/9976f92b-2c6f-4585-8dc6-be4c7a63b5ed)

![Fit 1](https://github.com/Jennstar01/Information/assets/157870001/4a003bf4-2c82-4c7f-9110-b1d6d6a6430c)

![Para 1](https://github.com/Jennstar01/Information/assets/157870001/d1e16cea-3328-4296-a397-0a9f9269c358)

![Para 2](https://github.com/Jennstar01/Information/assets/157870001/c5a1e52a-1c88-4927-ac12-dbf4ba7dbe47)

![para 3](https://github.com/Jennstar01/Information/assets/157870001/f8e7ba39-3a54-4527-a6c7-d72964f196b5)

![para 4](https://github.com/Jennstar01/Information/assets/157870001/f0d42c27-68f8-43af-87b2-6e9a75c6caec)

![para 5](https://github.com/Jennstar01/Information/assets/157870001/4c6ac91d-537e-4ce5-8eda-ee86234d072d)

![para 6](https://github.com/Jennstar01/Information/assets/157870001/c3514132-6230-4c12-ae8a-16d63ce03564)

![para 7](https://github.com/Jennstar01/Information/assets/157870001/2afdd85f-2766-473a-8f7e-ba53c7d5a978)

![fit 14](https://github.com/Jennstar01/Information/assets/157870001/58c199be-e28b-43a0-847b-57c1877058e1)

